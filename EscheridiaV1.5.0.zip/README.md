Created by QuirkyPlague
This shader is licsenced under MIT which means anything is fair use. I would prefer if you ask me before using my code and credit me where possible if used. 
If you have any issues, report them here or in my discord at https://discord.gg/BQAJxnQHMb
Hope you enjoy the shader!
